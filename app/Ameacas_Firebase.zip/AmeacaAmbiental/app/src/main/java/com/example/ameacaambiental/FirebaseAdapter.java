package com.example.ameacaambiental;

import java.util.List;

public class FirebaseAdapter<T> {
    public FirebaseAdapter(MainActivity mainActivity, Class<T> ameacaClass, int activityAmeacaListItem, List<T> ameacas) {
    }
}
