package com.example.ameacaambiental;

import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class addAmeaca extends AppCompatActivity {
    EditText txtDescricao, txtEndereco, txtData;
    Button btnSalvar;
        DatabaseReference mDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addameaca);

        txtDescricao = findViewById(R.id.descricao);
        txtData = findViewById(R.id.txtData);
        txtEndereco = findViewById(R.id.txtEndereco);

        btnSalvar = findViewById(R.id.btAdicionar);


         mDatabase = FirebaseDatabase.getInstance().getReference("ameaca");
        btnSalvar.setOnClickListener(v -> adicionarAmeaca());

    }

    public void adicionarAmeaca() {
        String descricao = txtDescricao.getText().toString();
        String endereco = txtEndereco.getText().toString();
        String data = txtData.getText().toString();
        if(descricao.isEmpty() || data.isEmpty() || endereco.isEmpty()){
            makeText(this, "Por favor, preencha todos os campos",
                    LENGTH_SHORT).show();
            return;
        }

        Ameaca ameaca = new Ameaca();
        ameaca.setData(data);
        ameaca.setDescricao(descricao);
        ameaca.setEndereco(endereco);


          mDatabase.push().setValue(ameaca)
                          .addOnSuccessListener(new OnSuccessListener<Void>() {
                              @Override
                              public void onSuccess(Void unused) {
                                  makeText(addAmeaca.this,"Ameaça adicionada com sucesso!", LENGTH_SHORT);
                                  txtDescricao.setText("");
                                  txtEndereco.setText("");
                                  txtData.setText("");

                                  Intent it = new Intent(getBaseContext(),MainActivity.class);
                                  setResult(addAmeaca.RESULT_OK,it);
                                  finish();

                              }
                          });
        addFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                makeText(addAmeaca.this, "Erro ao adicionar ameaça:", e.getMessage(), LENGTH_SHORT);

            }

            private void makeText(addAmeaca addAmeaca, String s, String message, int lengthShort) {
            }


        });

        txtDescricao.setText("");
        txtEndereco.setText("");
        txtData.setText("");
        Intent it = new Intent(getBaseContext(), MainActivity.class);
        setResult(addAmeaca.RESULT_OK, it);
        finish();
    }

    private void addFailureListener(OnFailureListener onFailureListener) {
    }

}