package com.example.ameacaambiental;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class AmeacaAdapter extends ArrayAdapter<Ameaca> {
    private final Context context;
    public int mResource;

    public AmeacaAdapter(Context context,int resource, List<Ameaca> ameacas) {
        super(context,resource, ameacas);
        this.context = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(mResource, parent, false);
        }

        Ameaca ameaca = getItem(position);

        if (ameaca != null) {
            TextView textViewDescricao = convertView.findViewById(R.id.descricao);
            textViewDescricao.setText(ameaca.getDescricao());

            TextView textViewData = convertView.findViewById(R.id.txtData);
            textViewData.setText(ameaca.getData());
        }

        return convertView;
    }
}